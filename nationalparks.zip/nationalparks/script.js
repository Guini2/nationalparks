function showMessage() {
    alert("Travel Tip: Visit during spring or fall to avoid crowds");
}
